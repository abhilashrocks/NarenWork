import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import * as Firebase from 'firebase/app';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [AngularFireAuth]
})
export class LoginComponent implements OnInit {
  user: Observable<Firebase.User>;
  authenticated = false;
  name: string;
  email: string;
  constructor(private router: Router, private af: AngularFireAuth) {
    this.af.authState.subscribe(auth => {
      if (auth != null) {
        this.name = auth.displayName;
        localStorage.setItem('username', this.name);
        localStorage.setItem('useremail', this.email);
        this.user = af.authState;
        this.authenticated = true;
      }
    });
  }

  ngOnInit() {}
  login() {
    this.af.auth
      .signInWithPopup(new Firebase.auth.GoogleAuthProvider())
      .then(() => {
        if (this.authenticated) {
          this.router.navigate(['home']);
        }
      });
  }
  logout() {
    this.af.auth.signOut();
    this.authenticated = false;
    this.router.navigate(['login']);
  }
}
