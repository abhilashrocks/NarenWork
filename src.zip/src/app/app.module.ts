import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AngularFireModule } from 'angularfire2';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AngularFireStorageModule} from 'angularfire2/storage';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

const fireBaseConfig = {
  apiKey: 'AIzaSyCJ1v4rMNqSYvlY-e--Jc_gDAUUn1MkImA',
  authDomain: 'narenwork-fc32e.firebaseapp.com',
  databaseURL: 'https://narenwork-fc32e.firebaseio.com',
  projectId: 'narenwork-fc32e',
  storageBucket: 'narenwork-fc32e.appspot.com',
  messagingSenderId: '1575959589'
};

const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: '**', component: LoginComponent },
  { path: '', component: LoginComponent }
];

@NgModule({
  declarations: [AppComponent, LoginComponent, HomeComponent],
  imports: [
    BrowserModule,
    AngularFireModule.initializeApp(fireBaseConfig),
    FormsModule,
    RouterModule.forRoot(appRoutes),
    BrowserAnimationsModule
  ],
  providers: [AngularFireStorageModule],
  bootstrap: [AppComponent]
})
export class AppModule {}
